import seaborn as sns
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt

# Set style
sns.set_style("whitegrid")

# Create sample data
data = pd.DataFrame({
    'Category': ['A', 'B', 'C', 'D', 'E'],
    'Values': [23, 45, 56, 78, 32]
})

# Create figure with subplots
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Matplotlib bar chart
axes[0].bar(data['Category'], data['Values'], color='skyblue')
axes[0].set_title('Bar Chart - Matplotlib')
axes[0].set_xlabel('Category')
axes[0].set_ylabel('Values')

# Seaborn bar plot
sns.barplot(data=data, x='Category', y='Values', ax=axes[1], palette='Set2')
axes[1].set_title('Bar Chart - Seaborn')

plt.tight_layout()
plt.show()