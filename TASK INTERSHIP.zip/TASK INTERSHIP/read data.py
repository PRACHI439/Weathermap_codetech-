# Install FPDF first:
# pip install fpdf

from fpdf import FPDF

# Step 1: Read data from file
file_name = "data.txt"

try:
    with open(file_name, "r") as file:
        numbers = [float(line.strip()) for line in file if line.strip()]

    # Check if file is empty
    if len(numbers) == 0:
        raise ValueError("No data found in file")

    # Step 2: Analyze the data
    total = sum(numbers)
    count = len(numbers)
    average = total / count
    maximum = max(numbers)
    minimum = min(numbers)

    # Step 3: Create PDF Report
    pdf = FPDF()
    pdf.add_page()

    # Title
    pdf.set_font("Arial", "B", 16)
    pdf.cell(200, 10, "Data Analysis Report", ln=True, align='C')

    pdf.ln(10)

    # Report Content
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, f"Total Numbers : {count}", ln=True)
    pdf.cell(200, 10, f"Sum            : {total}", ln=True)
    pdf.cell(200, 10, f"Average        : {average:.2f}", ln=True)
    pdf.cell(200, 10, f"Maximum Value  : {maximum}", ln=True)
    pdf.cell(200, 10, f"Minimum Value  : {minimum}", ln=True)

    # Save PDF
    pdf.output("report.pdf")

    print("PDF Report Generated Successfully: report.pdf")

except FileNotFoundError:
    print("Error: data.txt file not found.")

except ValueError as e:
    print("Error:", e)