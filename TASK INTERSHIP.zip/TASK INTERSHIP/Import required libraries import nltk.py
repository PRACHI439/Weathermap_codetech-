# Import required libraries
import nltk
from nltk.chat.util import Chat, reflections

# Define conversation pairs (patterns and responses)
pairs = [
    [
        r"hi|hello|hey",
        ["Hello!", "Hi there!", "Hey! Kaise ho?"]
    ],
    [
        r"what is your name?",
        ["I am a chatbot created using NLTK.", "You can call me ChatBot!"]
    ],
    [
        r"how are you?",
        ["I'm doing great!", "All good! Tum batao?"]
    ],
    [
        r"what can you do?",
        ["I can answer simple questions and chat with you!", "Basic chatbot hoon 😄"]
    ],
    [
        r"(.*) your name?",
        ["Mera naam ChatBot hai!"]
    ],
    [
        r"(.*) help (.*)",
        ["Sure! Main help karne ke liye hoon. Batao kya chahiye?"]
    ],
    [
        r"bye|exit|quit",
        ["Bye! Take care 👋", "Goodbye!"]
    ],
    [
        r"(.*)",
        ["Sorry, mujhe samajh nahi aaya 🤔", "Thoda aur clear bol sakte ho?"]
    ]
]

# Create chatbot
chatbot = Chat(pairs, reflections)

# Start conversation
print("🤖 Chatbot: Hello! Type 'bye' to exit.")

chatbot.converse()